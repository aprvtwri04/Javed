package com.cg.movie.controllers;
import java.util.List;
import javax.websocket.server.PathParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.movie.bean.Movie;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;
import com.cg.movie.services.MovieService;
@Controller
public class MovieServicesController {
	@Autowired
	MovieService movieService;
	//Method2
	@RequestMapping(value= {"/getMovieDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<Movie> getMovieDetailsRequestParam(@RequestParam int movieId)throws MovieDetailsNotFoundException
	{
		Movie movie  = movieService.getMovieDetails(movieId);
		return new ResponseEntity<Movie>(movie,HttpStatus.OK);
	}
	//Method1
	@RequestMapping(value= {"/getMovieDetails/{associateId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<Movie> getMovieDetailsRequestPathParam(@PathParam(value="movieId") int movieId)throws MovieDetailsNotFoundException
	{
		Movie movie  = movieService.getMovieDetails(movieId);
		return new ResponseEntity<Movie>(movie,HttpStatus.OK);
	}		
	@RequestMapping(value= {"/getAllMoviesDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Movie>> getAllMovieDetailsPathParam()throws MovieDetailsNotFoundException{
		return new ResponseEntity<List<Movie>>(movieService.getAllMoviesDetails(),HttpStatus.OK);
	}

	@RequestMapping(value= {"/acceptMovieDetails"},method=RequestMethod.POST,produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptMovieDetails(@ModelAttribute Movie movie){
		movie = movieService.acceptMovieDetails(movie);
		return new ResponseEntity<>("Movie details successfully added and movie ID is "+movie.getMovieId(),HttpStatus.OK);
	}
	@RequestMapping(value= {"/removeMovieDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> removeMovieDetailsRequestParam(@RequestParam int movieId)throws MovieDetailsNotFoundException
	{
		movieService.removeMovieDetails(movieId);
		return new ResponseEntity<>("Movie details successfully Removed",HttpStatus.OK);
	}	
}