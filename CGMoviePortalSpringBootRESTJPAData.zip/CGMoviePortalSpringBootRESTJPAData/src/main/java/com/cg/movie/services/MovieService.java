package com.cg.movie.services;

import java.util.List;

import com.cg.movie.bean.Movie;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;

public interface MovieService {
	
Movie acceptMovieDetails(Movie movie);

Movie getMovieDetails(int movieId) throws MovieDetailsNotFoundException;

List<Movie> getAllMoviesDetails()throws MovieDetailsNotFoundException;

public boolean update(Movie movie)throws MovieDetailsNotFoundException;

public boolean removeMovieDetails(int movieId)throws MovieDetailsNotFoundException;
}
