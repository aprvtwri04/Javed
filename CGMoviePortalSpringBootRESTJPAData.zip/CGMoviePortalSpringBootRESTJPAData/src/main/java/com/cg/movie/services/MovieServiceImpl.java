package com.cg.movie.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.bean.Movie;
import com.cg.movie.daoservices.MovieDAO;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;
@Component("movieService")
public class MovieServiceImpl implements MovieService{
	@Autowired
	private MovieDAO movieDAO;
	@Override
	public Movie acceptMovieDetails(Movie movie) {
		return movieDAO.save(movie);
	}
	@Override
	public Movie getMovieDetails(int movieId) throws MovieDetailsNotFoundException {
		return movieDAO.findById(movieId).orElseThrow(
				()->new MovieDetailsNotFoundException(
						"Movie Details not found for movie Id :-"+movieId));
	}
	@Override
	public List<Movie> getAllMoviesDetails() {
		return movieDAO.findAll();
	}
	@Override
	public boolean update(Movie movie) {
		movieDAO.save(movie);
		return true;
	}
	@Override
	public boolean removeMovieDetails(int movieId) {
		movieDAO.deleteById(movieId);
		return true;
	}
}
