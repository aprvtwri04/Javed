package com.cg.movie.bean;

import javax.persistence.Embeddable;

@Embeddable
public class Song {
	private String songType;
	private String songName;
	public Song(String songType, String songName) {
		super();
		this.songType = songType;
		this.songName = songName;
	}
	public Song() {}
	@Override
	public String toString() {
		return "Song [songType=" + songType + ", songName=" + songName + "]";
	}
	public String getSongType() {
		return songType;
	}
	public void setSongType(String songType) {
		this.songType = songType;
	}
	public String getSongName() {
		return songName;
	}
	public void setSongName(String songName) {
		this.songName = songName;
	}
	
	
}
