package com.cg.movie.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.movie.bean.Movie;

public interface MovieDAO extends JpaRepository<Movie, Integer>{
	@Query(value="from Movie m ")
	List<Movie> getAllMoviesDetails();
}
