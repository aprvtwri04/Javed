package com.cg.movie.bean;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Movie {
	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", moviePrice=" + moviePrice
				+ ", movieDuration=" + movieDuration + ", song=" + song + "]";
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int movieId;
	
	private String movieName;
	private int moviePrice;
	
	public Movie(String movieName, int moviePrice, int movieDuration, Song song) {
		super();
		this.movieName = movieName;
		this.moviePrice = moviePrice;
		this.movieDuration = movieDuration;
		this.song = song;
	}
	private int movieDuration;
	@Embedded
	public Song song;
	public Movie(int movieId, String movieName, int moviePrice, int movieDuration, Song song) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.moviePrice = moviePrice;
		this.movieDuration = movieDuration;
		this.song = song;
	}
	public Movie() {}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + movieDuration;
		result = prime * result + movieId;
		result = prime * result + ((movieName == null) ? 0 : movieName.hashCode());
		result = prime * result + moviePrice;
		result = prime * result + ((song == null) ? 0 : song.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (movieDuration != other.movieDuration)
			return false;
		if (movieId != other.movieId)
			return false;
		if (movieName == null) {
			if (other.movieName != null)
				return false;
		} else if (!movieName.equals(other.movieName))
			return false;
		if (moviePrice != other.moviePrice)
			return false;
		if (song == null) {
			if (other.song != null)
				return false;
		} else if (!song.equals(other.song))
			return false;
		return true;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public int getMoviePrice() {
		return moviePrice;
	}
	public void setMoviePrice(int moviePrice) {
		this.moviePrice = moviePrice;
	}
	public int getMovieDuration() {
		return movieDuration;
	}
	public void setMovieDuration(int movieDuration) {
		this.movieDuration = movieDuration;
	}
	public Song getSong() {
		return song;
	}
	public void setSong(Song song) {
		this.song = song;
	}
	
	
}
