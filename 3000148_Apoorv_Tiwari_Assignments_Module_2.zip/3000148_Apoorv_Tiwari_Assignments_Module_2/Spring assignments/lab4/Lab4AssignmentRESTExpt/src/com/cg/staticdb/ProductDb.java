package com.cg.staticdb;
import java.util.ArrayList;
import java.util.List;
import com.cg.bean.Product;

public class ProductDb {
	private static ArrayList<Product>productList=new ArrayList<>();
	static {
		productList.add(new Product("101", "Laptop", 45678.34));
		productList.add(new Product("102", "IPad", 65678.84));
		productList.add(new Product("103", "IPhone", 84678.34));
		productList.add(new Product("104", "IPod",1200.99));
		productList.add(new Product("105", "Hard Disk",5000.0));
		productList.add(new Product("106", "Data Cable",2000.15));
		productList.add(new Product("107", "Fit Bit Wrist Band",5000.78));
		productList.add(new Product("108", "Arm Sleeves",500.12));
		productList.add(new Product("109", "Adapter",4000.26));
		productList.add(new Product("110", "Samsung Tab",75678.0));
	}
	
	public static ArrayList<Product> getProductList(){
		return productList;	
	}
	
	public static void  getProductList(List<Product>productList) {
		ProductDb.productList=(ArrayList<Product>)productList;
	}
}
