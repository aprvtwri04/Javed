package com.cg.ctrl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Product;
import com.cg.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	IProductService service;

	public IProductService getService() {
		return service;
	}

	public void setService(IProductService service) {
		this.service = service;
	}
	
	@RequestMapping(value="/product",method=RequestMethod.GET,headers="Accept=Application/json")
	public List<Product> getAllProducts(Model model) {
		return service.getAllProducts();
	}

	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Product with this id not present")
    @ExceptionHandler({Exception.class})
    public void handleException() {
        
    }
	
	@RequestMapping(value="/product/search/{id}",method=RequestMethod.GET,headers="Accept=Application/json")
	public Product getProduct(@PathVariable int id) {
		return service.searchProduct(id);
	}
	
	@RequestMapping(value="/product/create/{prodId}/{prodName}/{prodPrice}",produces = "application/json",
			method = RequestMethod.POST)
	public List<Product >addProduct(@PathVariable String prodId,@PathVariable String prodName,@PathVariable double prodPrice,ModelAndView model){
		Product product=new Product();
		product.setProdId(prodId);
		product.setProdName(prodName);
		product.setProdPrice(prodPrice);
		
		service.addProduct(product);
		return service.getAllProducts();
		
	}

}
