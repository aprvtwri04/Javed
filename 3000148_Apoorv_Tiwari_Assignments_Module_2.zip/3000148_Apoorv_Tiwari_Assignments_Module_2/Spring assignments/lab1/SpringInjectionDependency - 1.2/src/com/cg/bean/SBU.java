package com.cg.bean;

public class SBU {
private int sbuId;
private String sbuName,sbuHead;

}
