package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cgbeans.xml");
		
		SBU sbu=(SBU)ctx.getBean("SbuObj");
		System.out.println("---------SBU Info-----------");
		System.out.println(" ID: "+sbu.getSbuCode()+
				" SBU Name: "+sbu.getSbuName()+
				" SBU Head: "+sbu.getSbuHead()+"\n");
		System.out.println("-------------Employee Details-------------------");
		System.out.println(" \n "+sbu.getEmpList());
				

	}

}
