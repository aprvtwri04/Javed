package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cgbeans.xml");
		
		Employee emp=(Employee)ctx.getBean("Obj");
		System.out.println("---------Employee Info-----------");
		System.out.println(" ID: "+emp.getEmployeeId()+
				" Name: "+emp.getEmployeeName()+
				" Age: "+emp.getAge()+
				" Business Unit: "+emp.getBusinessUnit()+
				" Salary: "+emp.getSalary());

	}

}
