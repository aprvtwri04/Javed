CREATE TABLE STUDENT_MARKS (
	student_code number(6),
	student_year number NOT NULL,
	subject1 number(3),
	subject2 number(3),
	subject3 number(3)
);