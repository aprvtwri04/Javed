create synonym synEmp 
	from EMP;