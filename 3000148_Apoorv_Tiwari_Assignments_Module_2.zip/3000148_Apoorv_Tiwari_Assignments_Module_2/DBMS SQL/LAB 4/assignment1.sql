CREATE TABLE CUSTOMER(
	customerid number(5),
	cust_name varchar2(20),
	address1 varchar2(30),
	address2 varchar2(30)
);