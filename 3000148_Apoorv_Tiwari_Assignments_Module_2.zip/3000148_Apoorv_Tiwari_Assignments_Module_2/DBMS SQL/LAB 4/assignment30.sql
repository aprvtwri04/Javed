select * 
	from user_synonyms
		where synonym_name='SYNEMP';