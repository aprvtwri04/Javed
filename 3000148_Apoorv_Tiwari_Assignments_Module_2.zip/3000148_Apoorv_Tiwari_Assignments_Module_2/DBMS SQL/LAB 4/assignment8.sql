alter table customer
	enable constraint custid_prim;